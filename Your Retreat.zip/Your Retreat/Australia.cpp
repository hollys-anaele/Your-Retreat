#include "Australia.h"
#include <iostream>
#include <string>
using namespace std;

void Australia:: setYellowFever(){
    string a = "";
    cout << "Have your children taken the Yellow Fever vaccine? 1 for YES, 2 for NO " << endl;
    cin >> a;

    if (a == "2"){
        cout << "You must take the Yellow Fever vaccine before attending your trip." <<endl;
    } 
    else
    cout << "You may proceed." << endl;


}