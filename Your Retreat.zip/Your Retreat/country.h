#ifndef COUNTRY_H
#define COUNTRY_H
#include <string>
using namespace std;

class Country {
    private:
        string name;
        int years;
        string children;
        string place;

    public:
        Country()
        {
            name = " ";
            years = 0;
            children = " ";
            place = " ";
        }

    Country(string n, int y, string c, string p){
        name = n;
        years = y;
        children = c;
        place = p;
    }

    void setName(string n)
    {name = n;}

    void setYears(int y)
    {years = y;}

    void setChildren(string c)
    {children = c;}

    void setPlace(string p)
    {place = p;}

    string getName() const
    {return name;}

    int getYears() const
    {return years;}

    string getChildren() const
    {return children;}

    string getPlace() const
    {return place;}

};

#endif

