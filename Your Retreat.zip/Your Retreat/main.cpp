#include <iostream>
#include <string>
#include <fstream>
#include "country.h"
#include "America.h"
#include "Africa.h"
#include "Australia.h"
#include "Asia.h"
#include "Europe.h"
#include "Stack.h"
using namespace std;


string name;
int years;
string children;
string place;
string myArray[5];
string mySecondArray[5];
string myThirdArray[5];
string myFourthArray[5];
string myFifthArray[5];
Stack stack(5);
string catchVar;
America an;
Africa af;
Australia au;
Asia as;
Europe eu;

int main()
{

    fstream file("file.txt");
    if(file.is_open())
    {

        for(int i = 0; i < 5; ++i)
        {
            file >> myArray[i];
        }
    }



    name = myArray[0];
    if (myArray[1] == "1"){
        years = 1;
    }
    if (myArray[1] == "2"){
        years = 2;
    }
    if (myArray[1] == "3"){
        years = 3;
    }
    if (myArray[1] == "4"){
        years = 4;
    }
    if (myArray[1] == "5"){
        years = 5;
    }
    if (myArray[1] == "6"){
        years = 6;
    }
    if (myArray[1] == "7"){
        years = 7;
    }
    if (myArray[1] == "8"){
        years = 8;
    }
    if (myArray[1] == "9"){
        years = 9;
    }

    children = myArray[2];
    place = myArray[3];


    Country c;
    c.setName(name);
    c.setYears(years);
    c.setChildren(children);
    c.setPlace(place);

 cout << "STATE DEPARTMENT - YOUR RETREAT" << endl;
 cout << "REGISTRATION BELOW" << endl;
 cout << "----------------------------------------------------------" << endl;
    cout << "Name: " << c.getName() << endl;
    cout << "Amount of Years in Foreign Service: " << c.getYears() << endl;
    cout << "Amount of Children:  " << c.getChildren() << endl;
    cout << "Continent of Location: " << c.getPlace() << endl;

if (c.getPlace() == "America"){
    an.setIllness();
}
if (c.getPlace() == "Africa"){
    af.setMalaria();
}
if (c.getPlace() == "Australia"){
    au.setYellowFever();
}
if (c.getPlace() == "Asia"){
    as.setMeasles();
}
if (c.getPlace() == "Europe"){
    eu.setTyphoid();
}


if (c.getYears() > 3){
    stack.push(c.getName());
}
else
cout << "Insufficient amount of years" << endl;


    fstream file_two("file_two.txt");
    if(file_two.is_open())
    {

        for(int i = 0; i < 5; ++i)
        {
            file_two >> mySecondArray[i];
        }
    }



    name = mySecondArray[0];
    if (mySecondArray[1] == "1"){
        years = 1;
    }
    if (mySecondArray[1] == "2"){
        years = 2;
    }
    if (mySecondArray[1] == "3"){
        years = 3;
    }
    if (mySecondArray[1] == "4"){
        years = 4;
    }
    if (mySecondArray[1] == "5"){
        years = 5;
    }
    if (mySecondArray[1] == "6"){
        years = 6;
    }
    if (mySecondArray[1] == "7"){
        years = 7;
    }
    if (mySecondArray[1] == "8"){
        years = 8;
    }
    if (mySecondArray[1] == "9"){
        years = 9;
    }

    children = mySecondArray[2];
    place = mySecondArray[3];


    c.setName(name);
    c.setYears(years);
    c.setChildren(children);
    c.setPlace(place);
cout << "----------------------------------------------------------" << endl;
    cout << "Name: " << c.getName() << endl;
    cout << "Amount of Years in Foreign Service: " << c.getYears() << endl;
    cout << "Amount of Children:  " << c.getChildren() << endl;
    cout << "Continent of Location: " << c.getPlace() << endl;

if (c.getPlace() == "America"){
    an.setIllness();
}
if (c.getPlace() == "Africa"){
    af.setMalaria();
}
if (c.getPlace() == "Australia"){
    au.setYellowFever();
}
if (c.getPlace() == "Asia"){
    as.setMeasles();
}
if (c.getPlace() == "Europe"){
    eu.setTyphoid();
}




if (c.getYears() > 3){
    stack.push(c.getName());
}
else
cout << "Insufficient amount of years" << endl;

    fstream file_three("file_three.txt");
    if(file_three.is_open())
    {

        for(int i = 0; i < 5; ++i)
        {
            file_three >> myThirdArray[i];
        }
    }



    name = myThirdArray[0];
    if (myThirdArray[1] == "1"){
        years = 1;
    }
    if (myThirdArray[1] == "2"){
        years = 2;
    }
    if (myThirdArray[1] == "3"){
        years = 3;
    }
    if (myThirdArray[1] == "4"){
        years = 4;
    }
    if (myThirdArray[1] == "5"){
        years = 5;
    }
    if (myThirdArray[1] == "6"){
        years = 6;
    }
    if (myThirdArray[1] == "7"){
        years = 7;
    }
    if (myThirdArray[1] == "8"){
        years = 8;
    }
    if (myThirdArray[1] == "9"){
        years = 9;
    }

    children = myThirdArray[2];
    place = myThirdArray[3];


    c.setName(name);
    c.setYears(years);
    c.setChildren(children);
    c.setPlace(place);
cout << "----------------------------------------------------------" << endl;
    cout << "Name: " << c.getName() << endl;
    cout << "Amount of Years in Foreign Service: " << c.getYears() << endl;
    cout << "Amount of Children:  " << c.getChildren() << endl;
    cout << "Continent of Location: " << c.getPlace() << endl;

if (c.getPlace() == "America"){
    an.setIllness();
}
if (c.getPlace() == "Africa"){
    af.setMalaria();
}
if (c.getPlace() == "Australia"){
    au.setYellowFever();
}
if (c.getPlace() == "Asia"){
    as.setMeasles();
}
if (c.getPlace() == "Europe"){
    eu.setTyphoid();
}

if (c.getYears() > 3){
    stack.push(c.getName());
}
else
cout << "Insufficient amount of years" << endl;

    fstream file_four("file_four.txt");
    if(file_four.is_open())
    {

        for(int i = 0; i < 5; ++i)
        {
            file_four >> myFourthArray[i];
        }
    }



    name = myFourthArray[0];
    if (myFourthArray[1] == "1"){
        years = 1;
    }
    if (myFourthArray[1] == "2"){
        years = 2;
    }
    if (myFourthArray[1] == "3"){
        years = 3;
    }
    if (myFourthArray[1] == "4"){
        years = 4;
    }
    if (myFourthArray[1] == "5"){
        years = 5;
    }
    if (myFourthArray[1] == "6"){
        years = 6;
    }
    if (myFourthArray[1] == "7"){
        years = 7;
    }
    if (myFourthArray[1] == "8"){
        years = 8;
    }
    if (myFourthArray[1] == "9"){
        years = 9;
    }

    children = myFourthArray[2];
    place = myFourthArray[3];


    c.setName(name);
    c.setYears(years);
    c.setChildren(children);
    c.setPlace(place);
cout << "----------------------------------------------------------" << endl;
    cout << "Name: " << c.getName() << endl;
    cout << "Amount of Years in Foreign Service: " << c.getYears() << endl;
    cout << "Amount of Children:  " << c.getChildren() << endl;
    cout << "Continent of Location: " << c.getPlace() << endl;

if (c.getPlace() == "America"){
    an.setIllness();
}
if (c.getPlace() == "Africa"){
    af.setMalaria();
}
if (c.getPlace() == "Australia"){
    au.setYellowFever();
}
if (c.getPlace() == "Asia"){
    as.setMeasles();
}
if (c.getPlace() == "Europe"){
    eu.setTyphoid();
}

if (c.getYears() > 3){
    stack.push(c.getName());
}
else
cout << "Insufficient amount of years" << endl;

    fstream file_five("file_five.txt");
    if(file_five.is_open())
    {

        for(int i = 0; i < 5; ++i)
        {
            file_five >> myFifthArray[i];
        }
    }



    name = myFifthArray[0];
    if (myFifthArray[1] == "1"){
        years = 1;
    }
    if (myFifthArray[1] == "2"){
        years = 2;
    }
    if (myFifthArray[1] == "3"){
        years = 3;
    }
    if (myFifthArray[1] == "4"){
        years = 4;
    }
    if (myFifthArray[1] == "5"){
        years = 5;
    }
    if (myFifthArray[1] == "6"){
        years = 6;
    }
    if (myFifthArray[1] == "7"){
        years = 7;
    }
    if (myFifthArray[1] == "8"){
        years = 8;
    }
    if (myFifthArray[1] == "9"){
        years = 9;
    }

    children = myFifthArray[2];
    place = myFifthArray[3];


    c.setName(name);
    c.setYears(years);
    c.setChildren(children);
    c.setPlace(place);
cout << "----------------------------------------------------------" << endl;
    cout << "Name: " << c.getName() << endl;
    cout << "Amount of Years in Foreign Service: " << c.getYears() << endl;
    cout << "Amount of Children:  " << c.getChildren() << endl;
    cout << "Continent of Location: " << c.getPlace() << endl;

if (c.getPlace() == "America"){
    an.setIllness();
}
if (c.getPlace() == "Africa"){
    af.setMalaria();
}
if (c.getPlace() == "Australia"){
    au.setYellowFever();
}
if (c.getPlace() == "Asia"){
    as.setMeasles();
}
if (c.getPlace() == "Europe"){
    eu.setTyphoid();
}

if (c.getYears() > 3){
    stack.push(c.getName());
}
else
cout << "Insufficient amount of years" << endl;


cout << "----------------------------------------------------------" << endl;
cout << "FOREIGN SERVICE OFFICERS CONFIRMED FOR REGISTRATION" << endl;

stack.pop(catchVar);
cout << catchVar << endl;
stack.pop(catchVar);
cout << catchVar << endl;
stack.pop(catchVar);
cout << catchVar << endl;
cout << " " << endl;
cout << " " << endl;
cout << "Thank you for using YourRetreat. Enjoy your trip!" << endl;
cout << " " << endl;
cout << " " << endl;
cout << " " << endl;


return 0;



}