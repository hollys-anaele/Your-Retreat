#ifndef AUSTRALIA_H
#define AUSTRALIA_H
#include "country.h"
#include <string>
using namespace std;

class Australia: public Country {

    private:
    string yellowfever;

    public:
    void setYellowFever();
};

#endif