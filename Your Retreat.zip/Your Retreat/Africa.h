#ifndef AFRICA_H
#define AFRICA_H
#include "country.h"
#include <string>
using namespace std;

class Africa: public Country {

    private:
    string malaria;

    public:
    void setMalaria();
};

#endif