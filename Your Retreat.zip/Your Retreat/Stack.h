#ifndef STACK_H
#define STACK_H
using namespace std;

class Stack{

    private:
    string *stackArray;
    int stackSize;
    int top;

    public:

    Stack(int);

    Stack(const Stack &);

    ~Stack();

    void push(string);
    void pop(string &);
    bool isFull() const;
    bool isEmpty() const;


};
#endif
