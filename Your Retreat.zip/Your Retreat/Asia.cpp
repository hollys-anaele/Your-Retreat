#include "Asia.h"
#include <iostream>
#include <string>
using namespace std;

void Asia:: setMeasles(){
    string a = "";
    cout << "Have your children taken the Measles vaccine? 1 for YES, 2 for NO " << endl;
    cin >> a;

    if (a == "2"){
        cout << "You must take the Measles vaccine before attending your trip." <<endl;
    } 
    else
    cout << "You may proceed." << endl;




};