#include "Europe.h"
#include <iostream>
#include <string>
using namespace std;

void Europe:: setTyphoid(){
    string a = "";
    cout << "Has your child taken the Typhoid vaccine? 1 for YES, 2 for NO " << endl;
    cin >> a;

    if (a == "2"){
        cout << "You must take the Typhoid vaccine before attending your trip." <<endl;
    } 
    else
    cout << "You may proceed." << endl;




};