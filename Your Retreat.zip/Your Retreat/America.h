#ifndef AMERICA_H
#define AMERICA_H
#include "country.h"
#include <string>
using namespace std;

class America: public Country {

    private:
    string illness;

    public:
    void setIllness();
};

#endif