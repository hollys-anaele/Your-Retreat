#ifndef ASIA_H
#define ASIA_H
#include "country.h"
#include <string>
using namespace std;

class Asia: public Country {

    private:
    string measles;

    public:
    void setMeasles();
};

#endif