#include "Africa.h"
#include <iostream>
#include <string>
using namespace std;

void Africa:: setMalaria(){
    string a = "";
    cout << "Have your children taken the Malaria vaccine? 1 for YES, 2 for NO " << endl;
    cin >> a;

    if (a == "2"){
        cout << "You must take the Malaria vaccine before attending your trip." <<endl;
    } 
    else
    cout << "You may proceed." << endl;




};