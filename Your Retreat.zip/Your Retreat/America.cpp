#include "America.h"
#include <iostream>
#include <string>
using namespace std;

void America:: setIllness(){
    string a = "";
    cout << "Do your children have any illnesses? 1 for YES, 2 for NO " << endl;
    cin >> a;

    if (a == "1"){
        cout << "Please check with your doctor before attending trip." <<endl;
    } 
    else
    cout << "You may proceed." << endl;




};