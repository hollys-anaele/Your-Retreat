#ifndef EUROPE_H
#define EUROPE_H
#include "country.h"
#include <string>
using namespace std;

class Europe: public Country {

    private:
    string Typhoid;

    public:
    void setTyphoid();
};

#endif